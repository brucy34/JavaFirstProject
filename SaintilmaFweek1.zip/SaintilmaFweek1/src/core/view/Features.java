package core.view;

public abstract class Features {

    public static void display(String a){
        System.out.println(a);
    }
}

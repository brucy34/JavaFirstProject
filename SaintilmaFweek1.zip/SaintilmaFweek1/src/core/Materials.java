package core;

public class Materials {

	private int materialID;
	private String materialName;
	private String materialType;
	
	
	public Materials(int materialID,String materialName,String materialType)
	{
		this.materialID =materialID;
		this.materialName = materialName;
		this.materialType = materialType;
	}
	public int getMaterialID() {
		return materialID;
	}
	public void setMaterialID(int materialID) {
		this.materialID = materialID;
	}
	public String getMaterialName() {
		return materialName;
	}
	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}
	public String getMaterialType() {
		return materialType;
	}
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	
	
	
}

package core;

public class Course {
	
	
	private int courseID;
	private String nameCourse;
	private int numberOfHour;
	
	
	
	
	public Course(int courseID,String nameCourse,int numberOfHour)
	{
		this.courseID = courseID;
		this.nameCourse = nameCourse;
		this.numberOfHour = numberOfHour;
	}
	public int getCourseID() {
		return courseID;
	}
	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}
	public String getNameCourse() {
		return nameCourse;
	}
	public void setNameCourse(String nameCourse) {
		this.nameCourse = nameCourse;
	}
	public int getNumberOfHour() {
		return numberOfHour;
	}
	public void setNumberOfHour(int numberOfHour) {
		this.numberOfHour = numberOfHour;
	}
	@Override
	public String toString() {
		return "Course [courseID=" + courseID + ", nameCourse=" + nameCourse + ", numberOfHour=" + numberOfHour + "]";
	}
	
	
	

}
